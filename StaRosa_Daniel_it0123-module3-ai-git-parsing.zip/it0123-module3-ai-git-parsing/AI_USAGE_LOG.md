# AI Usage and Validation Log

Student name: Daniel A. Sta. Rosa
Section: TN32
AI tool used: ChatGPT

## Entry 1 - XML parsing

Prompt:
I am completing an authorized classroom Python lab.
 Review this function stub and the supplied fictional [XML/JSON/YAML] structure.
 Recommend an implementation that returns exactly the keys described in the docstring.
 Explain namespace handling, data types, error risks, and each library function used.
 Do not invent files, credentials, network calls, or expected test results.
 I will validate your recommendation using unit tests and Git diffs.
 
 Function stub: 
def parse_xml(path: str | Path) -> dict:
    """Return default_operation and test_option from the NETCONF-style XML."""
    # TODO: parse the XML, handle its default namespace, and return two strings.
    raise NotImplementedError("Complete parse_xml")
 Relevant fictional data:
<?xml version="1.0" encoding="UTF-8"?>
<rpc message-id="101" xmlns="urn:ietf:params:xml:ns:netconf:base:1.0">
  <edit-config>
    <target>
      <candidate />
    </target>
    <default-operation>merge</default-operation>
    <test-option>test-then-set</test-option>
    <config>
      <interface xmlns="urn:example:network">
        <name>GigabitEthernet1</name>
        <enabled>true</enabled>
      </interface>
    </config>
  </edit-config>
</rpc>

AI recommendation summary:

from pathlib import Path
import xml.etree.ElementTree as ET


def parse_xml(path: str | Path) -> dict:
    """Return default_operation and test_option from the NETCONF-style XML."""
    root = ET.parse(path).getroot()

    netconf_ns = "urn:ietf:params:xml:ns:netconf:base:1.0"

    default_operation = root.find(
        f"{{{netconf_ns}}}edit-config/{{{netconf_ns}}}default-operation"
    )
    test_option = root.find(
        f"{{{netconf_ns}}}edit-config/{{{netconf_ns}}}test-option"
    )

    if default_operation is None or default_operation.text is None:
        raise ValueError("Missing NETCONF default-operation element")
    if test_option is None or test_option.text is None:
        raise ValueError("Missing NETCONF test-option element")

    return {
        "default_operation": default_operation.text.strip(),
        "test_option": test_option.text.strip(),
    }

Decision: accepted

Validation evidence:

test_xml_default_operation (test_parser.ParserTests.test_xml_default_operation) ... ok
test_xml_test_option (test_parser.ParserTests.test_xml_test_option) ... ok

## Entry 2 - JSON parsing

Prompt:
I am completing an authorized classroom Python lab.
 Review this function stub and the supplied fictional [XML/JSON/YAML] structure.
 Recommend an implementation that returns exactly the keys described in the docstring.
 Explain namespace handling, data types, error risks, and each library function used.
 Do not invent files, credentials, network calls, or expected test results.
 I will validate your recommendation using unit tests and Git diffs.
 
 Function stub:
def parse_json(path: str | Path) -> dict:
    """Return site, device_count, enabled_devices, and roles from the JSON."""
    # TODO: use json.load and derive the requested summary values.
    raise NotImplementedError("Complete parse_json")
 Relevant fictional data:
{
  "site": "FEU-Tech-Lab",
  "devices": [
    {
      "hostname": "R1",
      "management_ip": "192.0.2.10",
      "role": "router",
      "enabled": true
    },
    {
      "hostname": "SW1",
      "management_ip": "192.0.2.20",
      "role": "switch",
      "enabled": true
    },
    {
      "hostname": "AP1",
      "management_ip": "192.0.2.30",
      "role": "wireless-ap",
      "enabled": false
    }
  ]
}

AI recommendation summary:

import json
from pathlib import Path


def parse_json(path: str | Path) -> dict:
    """Return site, device_count, enabled_devices, and roles from the JSON."""
    with open(path, encoding="utf-8") as file:
        data = json.load(file)

    devices = data["devices"]

    return {
        "site": data["site"],
        "device_count": len(devices),
        "enabled_devices": [
            device["hostname"]
            for device in devices
            if device["enabled"] is True
        ],
        "roles": [device["role"] for device in devices],
    }

Decision: accepted

Validation evidence:

test_json_device_count (test_parser.ParserTests.test_json_device_count) ... ok
test_json_enabled_devices (test_parser.ParserTests.test_json_enabled_devices) ... ok
test_json_roles (test_parser.ParserTests.test_json_roles) ... ok

## Entry 3 - YAML parsing and integration

Prompt:

I am completing an authorized classroom Python lab.
 Review this function stub and the supplied fictional [XML/JSON/YAML] structure.
 Recommend an implementation that returns exactly the keys described in the docstring.
 Explain namespace handling, data types, error risks, and each library function used.
 Do not invent files, credentials, network calls, or expected test results.
 I will validate your recommendation using unit tests and Git diffs.
 
Function stub:
def parse_yaml(path: str | Path) -> dict:
    """Return name, approved, duration_minutes, devices, and action from YAML."""
    # TODO: use yaml.safe_load and return the normalized maintenance summary.
    raise NotImplementedError("Complete parse_yaml")
Relevant fictional data:
window:
  name: Saturday-Lab
  approved: true
  duration_minutes: 90
devices:
  - R1
  - SW1
action: validate-configuration


I am completing an authorized classroom Python lab.
 Review this function stub and the supplied fictional [XML/JSON/YAML] structure.
 Recommend an implementation that returns exactly the keys described in the docstring.
 Explain namespace handling, data types, error risks, and each library function used.
 Do not invent files, credentials, network calls, or expected test results.
 I will validate your recommendation using unit tests and Git diffs.
 
 Function stub:   
def build_summary(xml_path: str | Path, json_path: str | Path, yaml_path: str | Path) -> dict:
    """Combine the three parser results into one dictionary."""
    # TODO: call the three parser functions and preserve the keys below.
    raise NotImplementedError("Complete build_summary")
Relevant fictional data:
import json
import xml.etree.ElementTree as ET
from pathlib import Path

import yaml

def parse_xml(path: str | Path) -> dict:
    """Return default_operation and test_option from the NETCONF-style XML."""
    root = ET.parse(path).getroot()

    netconf_ns = "urn:ietf:params:xml:ns:netconf:base:1.0"

    default_operation = root.find(
        f"{{{netconf_ns}}}edit-config/{{{netconf_ns}}}default-operation"
    )
    test_option = root.find(
        f"{{{netconf_ns}}}edit-config/{{{netconf_ns}}}test-option"
    )

    if default_operation is None or default_operation.text is None:
        raise ValueError("Missing NETCONF default-operation element")
    if test_option is None or test_option.text is None:
        raise ValueError("Missing NETCONF test-option element")

    return {
        "default_operation": default_operation.text.strip(),
        "test_option": test_option.text.strip(),
    }

def parse_json(path: str | Path) -> dict:
    """Return site, device_count, enabled_devices, and roles from the JSON."""
    with open(path, encoding="utf-8") as file:
        data = json.load(file)

    devices = data["devices"]

    return {
        "site": data["site"],
        "device_count": len(devices),
        "enabled_devices": [
            device["hostname"]
            for device in devices
            if device["enabled"] is True
        ],
        "roles": [device["role"] for device in devices],
    }

def parse_yaml(path: str | Path) -> dict:
    """Return name, approved, duration_minutes, devices, and action from YAML."""
    with open(path, encoding="utf-8") as file:
        data = yaml.safe_load(file)

    window = data["window"]

    return {
        "name": window["name"],
        "approved": window["approved"],
        "duration_minutes": window["duration_minutes"],
        "devices": list(data["devices"]),
        "action": data["action"],
    }

def build_summary(xml_path: str | Path, json_path: str | Path, yaml_path: str | Path) -> dict:
    """Combine the three parser results into one dictionary."""
    # TODO: call the three parser functions and preserve the keys below.
    raise NotImplementedError("Complete build_summary")


if __name__ == "__main__":
    base = Path(__file__).resolve().parent
    summary = build_summary(
        base / "network_config.xml",
        base / "devices.json",
        base / "maintenance.yaml",
    )
    print(json.dumps(summary, indent=2))

AI recommendation summary:

from pathlib import Path

import yaml


def parse_yaml(path: str | Path) -> dict:
    """Return name, approved, duration_minutes, devices, and action from YAML."""
    with open(path, encoding="utf-8") as file:
        data = yaml.safe_load(file)

    window = data["window"]

    return {
        "name": window["name"],
        "approved": window["approved"],
        "duration_minutes": window["duration_minutes"],
        "devices": list(data["devices"]),
        "action": data["action"],
    }

def build_summary(
    xml_path: str | Path,
    json_path: str | Path,
    yaml_path: str | Path,
) -> dict:
    """Combine the three parser results into one dictionary."""
    xml_summary = parse_xml(xml_path)
    json_summary = parse_json(json_path)
    yaml_summary = parse_yaml(yaml_path)

    return {
        **xml_summary,
        **json_summary,
        **yaml_summary,
    }
    
Decision: accepted 

Validation evidence:

test_yaml_window (test_parser.ParserTests.test_yaml_window) ... ok
test_combined_summary (test_parser.ParserTests.test_combined_summary) ... ok

## Controlled merge-conflict line

Validation status: AI reviewed

## Final reflection

Describe one AI suggestion that you changed or rejected and explain the evidence that guided your decision.
