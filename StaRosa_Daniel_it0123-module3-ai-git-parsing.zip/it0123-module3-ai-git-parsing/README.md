# AI-Assisted Git Workflow and Python Data Parsing

Student name: Daniel A. Sta. Rosa
Section: TN32

## Project purpose

using version control, creates a branch to make a controlled edit on the parser template, then merges it back to main once validated.

## How to run

```bash
python3 parser_template.py
python3 -m unittest -v
```

## Git workflow summary

main
feature/data-parsers
docs/ai-note

## Parser results

{
  "xml": {
    "default_operation": "merge",
    "test_option": "test-then-set"
  },
  "json": {
    "site": "FEU-Tech-Lab",
    "device_count": 3,
    "enabled_devices": [
      "R1",
      "SW1"
    ],
    "roles": [
      "router",
      "switch",
      "wireless-ap"
    ]
  },
  "yaml": {
    "name": "Saturday-Lab",
    "approved": true,
    "duration_minutes": 90,
    "devices": [
      "R1",
      "SW1"
    ],
    "action": "validate-configuration"
  }
}

## AI disclosure

Used ChatGPT and heavily relied on unit tests for validation

## Safety statement

Confirmed that only the provided fictional data was used and that no credentials, tokens, private repository data, or personal information were submitted to AI.
